ime			memorija u kB	entropija
TimeMachine.txt		201,9 		4.521185
TimeMachine.txt.xz	68,7		7.997535
TimeMachine.txt.7z	68,8		7.997090
TimeMachine.zip		76,9		7.996864
TimeMachine.rar		72,6		7.996781
TimeMachine.txt.gz	77,5		7.996279
TimeMachine.txt.tar	203,8		4.556541

Ocekivani output kod pokretanja na Linux OS-u
(Izvorno rađeno na Linux Mint distribuciji)
TimeMachine.txt
total: 201900
used: 87
H: 4.521185

TimeMachine.txt.xz
total: 68704
used: 256
H: 7.997535

TimeMachine.txt.7z
total: 68763
used: 256
H: 7.997090

TimeMachine.zip
total: 76914
used: 256
H: 7.996864

TimeMachine.rar
total: 72629
used: 256
H: 7.996781

TimeMachine.txt.gz
total: 77547
used: 256
H: 7.996279

TimeMachine.txt.tar
total: 203776
used: 88
H: 4.556541

